item modify block ~ ~ ~ container.4 imui:add_count
execute unless items block ~ ~ ~ container.4 * run item replace block ~ ~ ~ container.4 from entity @s weapon.mainhand imui:limit_count
item modify entity @s weapon.mainhand imui:decrease_count
