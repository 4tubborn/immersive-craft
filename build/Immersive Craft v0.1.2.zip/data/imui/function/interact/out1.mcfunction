advancement revoke @s only imui:interact/out1
scoreboard players set #type imui.tmp 1
execute anchored eyes run function imui:ray/init
