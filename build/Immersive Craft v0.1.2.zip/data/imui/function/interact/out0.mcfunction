advancement revoke @s only imui:interact/out0
scoreboard players set #type imui.tmp 0
execute anchored eyes run function imui:ray/init
