advancement revoke @s only imui:interact/out2
scoreboard players set #type imui.tmp 2
execute anchored eyes run function imui:ray/init
