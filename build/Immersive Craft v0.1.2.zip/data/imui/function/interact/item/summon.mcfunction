summon item ~ ~ ~ {Item:{id:"barrier",components:{}},Tags:["imui.give"]}
