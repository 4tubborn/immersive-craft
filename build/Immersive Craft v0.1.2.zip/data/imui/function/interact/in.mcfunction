advancement revoke @s only imui:interact/in
scoreboard players set #type imui.tmp 3
execute anchored eyes run function imui:ray/init
