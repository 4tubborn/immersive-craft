advancement revoke @s only imui:interact/fuel
scoreboard players set #type imui.tmp 4
execute anchored eyes run function imui:ray/init
