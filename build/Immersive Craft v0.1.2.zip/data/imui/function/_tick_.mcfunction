execute as @e[type=item_display,tag=imui.item] at @s run function imui:tick/dispatch/item
execute as @e[type=text_display,tag=imui.text] at @s run function imui:tick/dispatch/text
execute as @e[type=marker,tag=imui.marker] at @s unless block ~ ~ ~ brewing_stand align xyz run function imui:remove/_
